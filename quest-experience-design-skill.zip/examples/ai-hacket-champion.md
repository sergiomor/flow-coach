# Example Quest: The AI Hacket Champion

## Quest Overview

**Type**: Experience-Based (Competition)  
**Duration**: 48 hours (weekend hackathon)  
**Difficulty**: Intermediate  
**Location**: Auckland, New Zealand (or other major city)  

## Narrative

The AI Hacket is New Zealand's premier AI hackathon - a high-energy, 48-hour sprint where innovators, developers, and dreamers come together to build the impossible. You're not just here to code; you're here to push boundaries, solve real problems, and prove that you can ship working AI solutions under pressure.

Your NPC mentor, Kōtuku (named after the rare white heron - a symbol of excellence), is a veteran hackathon champion who knows all the strategies for success. They've been in the trenches, survived the 3am debugging sessions, and tasted victory. Now they're here to guide you through your own epic journey.

Will you emerge victorious, or at least battle-tested and wiser? Either way, you'll slay the dragon of self-doubt and prove you can ship when it counts.

## The Dragon

**Internal Obstacle**: Fear of not being good enough / imposter syndrome in competitive technical environment

**Dragon Moment**: Hour 24-30 - The "grind zone" where exhaustion hits, bugs multiply, and doubt creeps in. This is where most teams consider giving up or drastically scaling back their ambitions.

**Dragon Support**: Kōtuku will check in during this critical period with encouragement, perspective-shifting questions, and tactical advice on prioritization and scope management.

## Quest Structure

### Task 0: Pre-Hacket Preparation (Before Event)
**Objective**: Prepare for battle - assemble team, choose tech stack, scout challenges  
**Challenge**: Planning and coordination before time pressure hits  
**Verification**: Team registration confirmation + tech stack declaration  
**Dragon**: Small - commitment anxiety  

**NPC Dialogue** (Kōtuku):
> "Kia ora, future champion! The AI Hacket isn't won by luck - it's won by warriors who prepare. First quest: Assemble your fellowship. A good team has diverse skills: the visionary, the builder, the designer, the presenter. You need all these roles. Once you have your team, declare your weapons - what tech stack will you wield? Choose wisely, but remember: the best tools are the ones you already know how to use under pressure."

### Task 1: Pitch Selection & Strategy (Hour 0-2)
**Objective**: Choose challenge, define scope, create battle plan  
**Challenge**: Making smart decisions under excitement and time pressure  
**Verification**: Team strategy document + Kōtuku consultation  
**Dragon**: Small - fear of choosing wrong challenge  

**NPC Dialogue** (Kōtuku):
> "The challenges have been revealed! Listen carefully: Don't pick the flashiest challenge - pick the one where you can deliver real value. The judges love ambition, but they love working demos more. Here's your framework: 1) Can we build a working prototype in 36 hours? 2) Does it solve a real problem? 3) Can we make it impressive? All three must be YES. Now, tell me your strategy. What will you build, and what will you NOT build?"

### Task 2: Foundation Sprint (Hour 2-12)
**Objective**: Build core functionality and basic UI  
**Challenge**: Staying focused on MVP, resisting feature creep  
**Verification**: Working basic demo + git commits showing progress  
**Dragon**: Small - excitement-driven scope creep  

**NPC Dialogue** (Kōtuku):
> "This is where discipline wins. I know you're excited and want to add every cool feature you imagine, but NO. Build the skeleton first. Core functionality only. Make. It. Work. Then, and only then, add polish. Check in with me at Hour 6 and Hour 12 - I'll help you stay on track."

### Task 3: The Grind (Hour 12-30) - THE DRAGON
**Objective**: Push through exhaustion, fix critical bugs, maintain morale  
**Challenge**: Battling fatigue, frustration, and mounting problems  
**Verification**: Continued progress + team check-in + problem documentation  
**Dragon**: MAIN - exhaustion, doubt, overwhelm  

**NPC Dialogue** (Kōtuku - Hour 24):
> "Here we are. The dragon moment. Every champion faces this - it's 2am, your code is broken, your team is tired, and you're wondering if you should just give up or pivot to something easier. Listen to me: This is the moment that separates the badge-earners from the quitters. The dragon is whispering that you're not good enough, that you should have picked an easier challenge, that you should cut your losses. But here's the truth: you're closer than you think. Every bug you fix is progress. Every team that quits is one less competitor. You don't have to be perfect - you have to be persistent. Tell me: what's the ONE critical bug blocking you? Let's slay it together. You've got this."

**Post-Dragon Dialogue** (Kōtuku):
> "You did it! You pushed through! Look at what you've built. At Hour 12 it was nothing, and now look. THIS is what you're capable of under pressure. The dragon tried to stop you and failed. Remember this moment - it's proof that you can do hard things."

### Task 4: Polish & Presentation Prep (Hour 30-40)
**Objective**: Polish demo, prepare pitch deck, practice presentation  
**Challenge**: Optimizing for judges vs. perfect code  
**Verification**: Pitch deck + practiced presentation + demo rehearsal  
**Dragon**: Small - perfectionism  

**NPC Dialogue** (Kōtuku):
> "Victory is within reach. Now we shift gears - from building to storytelling. Remember: judges have 5 minutes with each team. They won't read your code. They won't see your elegant architecture. They'll see: 1) Does it work? 2) Does it solve something real? 3) Can this team articulate value? Make your demo bulletproof - test every click path. Make your story compelling - why does this matter? Practice your pitch three times minimum. I'll watch and give notes."

### Task 5: The Presentation (Hour 40-44)
**Objective**: Deliver compelling pitch and demo to judges  
**Challenge**: Performing under pressure with whole team watching  
**Verification**: Presentation video + judge feedback  
**Dragon**: Medium - performance anxiety  

**NPC Dialogue** (Kōtuku):
> "This is it. The culmination of 48 hours of effort. Remember: confidence comes from preparation. You've rehearsed. Your demo works. Your story is clear. Take a breath. Look the judges in the eye. Speak with conviction. You've earned the right to be here. Show them what you built. Show them why it matters. And most importantly: have fun. This is your moment to shine."

### Task 6: Reflection & Learning Capture (Post-Event)
**Objective**: Document learnings, celebrate achievements, plan next steps  
**Challenge**: Moving from exhaustion to reflection  
**Verification**: Reflection document (learnings, wins, growth areas) + public share  
**Dragon**: None - celebrating completion  

**NPC Dialogue** (Kōtuku):
> "Ka pai, warrior! Whether you won an award or not, you completed the AI Hacket. You built something from nothing in 48 hours. You slayed your dragon. Now, while it's fresh, capture the magic: What surprised you? What was harder than expected? What did you learn about yourself, your team, technical skills? What would you do differently next time? Write it down. This wisdom is your real prize. And post about your journey - your story might inspire the next wave of hacket champions."

## Rewards

### Primary Reward
**AI Hacket Champion Badge**
- Visual badge showing a stylized AI brain with hackathon lightning bolts
- Metadata includes: project built, tech stack used, team role, competition placement
- Shareable with employers and on professional profiles

### Secondary Rewards
- **Official AI Hacket Certificate** (if applicable from event organizers)
- **Project Portfolio Piece** - documented case study of what was built
- **Unlocks**: Advanced AI Challenge quests, Mentor Program (help future hacket participants)
- **Community**: Join AI Hacket Alumni network for future opportunities
- **Recognition**: Featured on quest platform's champion showcase

### Intrinsic Rewards
- Proved you can build under pressure
- Overcame imposter syndrome and self-doubt
- Learned rapid prototyping and shipping skills
- Built teamwork and collaboration capabilities
- Earned war stories and bragging rights
- Made connections with other builders

### Potential External Rewards (Event-Specific)
- Prize money (if won)
- Sponsor opportunities
- Job offers and recruitment connections
- Media coverage
- Startup accelerator invitations

## Verification Method

**Pre-Event Tasks**: Email confirmation, team registration screenshot  
**During Event**: 
- Git commit logs showing contribution
- Progress photos/videos at checkpoints
- Kōtuku check-in conversations (logged in app)
- Judge feedback forms
**Post-Event**: 
- Final project submission link
- Presentation recording
- Reflection document (verified for substance by NPC)

**Anti-Gaming Measures**:
- Team registration must match actual event registration
- Git commits must show authentic contribution (not just opening/closing brackets)
- Check-ins must occur during actual event hours
- Project must be visible/verifiable via event platform
- Reflection must demonstrate genuine engagement (not generic/AI-generated)

## Success Metrics

**Completion Rate Target**: 85% (high because registration indicates serious commitment)  
**Average Duration**: 48 hours (event length) + 2 hours reflection  
**Dragon Success Rate**: 70% (pushing through Hour 24-30 grind)  
**User Satisfaction**: 4.7/5 stars (intense but rewarding)  
**Re-engagement**: 60% do another hackathon quest within 6 months  

## Design Notes

### Why This Quest Works

1. **Real Event Integration**: Tied to actual AI Hacket competitions
2. **Critical Support**: NPC provides guidance at key decision points and dragon moment
3. **Authentic Dragon**: The Hour 24-30 grind is a real, documented phenomenon in hackathons
4. **Skill Development**: Participants learn rapid prototyping, teamwork, presenting
5. **Prestige Factor**: Completing hackathons carries real professional value
6. **Community Building**: Creates cohort of fellow survivors/champions

### Adaptations for Different Hackets

This quest template can be adapted for:
- **Different AI Hacket Events**: Wellington, Christchurch, online versions
- **Other Hackathons**: Fintech, GovTech, HealthTech, general coding
- **Different Durations**: 24-hour sprints, week-long challenges
- **Different Skill Levels**: Beginner hackets with more scaffolding, expert-level with higher expectations

### Partnership Opportunities

- **AI Hacket Organizers**: Official quest platform partnership
- **Sponsors**: Additional rewards for quest completers
- **Universities**: Academic credit or capstone project recognition
- **Employers**: Recruit from badge holders
- **Tech Communities**: Co-marketing and promotion

## Related Quests

**Prerequisites**: 
- "Build Your First AI App" (Beginner) - optional but recommended
- "Git & GitHub Essentials" (Beginner) - helpful for collaboration

**Unlocks**: 
- "AI Hacket Mentor" (Advanced) - help guide future participants
- "Startup Sprint" (Advanced) - turn hackathon project into actual startup
- "Global Hackathon Circuit" (Expert) - compete in international events

**Part of Chain**: 
- AI Builder Series (10 progressive challenges)
- Competition Champion Track (various competitive events)

---

This quest transforms a hackathon from a stressful coding marathon into an epic adventure with clear support systems, narrative structure, and recognition of both the technical and psychological challenges involved.
