# Example Quest: The Wellington on a Plate Gastronaut

## Quest Overview

**Type**: Experience-Based (Exploration - Culinary Event)  
**Duration**: 2-4 weeks (during event period)  
**Difficulty**: Beginner  
**Location**: Wellington, New Zealand  

## Narrative

Every August, Wellington transforms into the culinary capital of the Southern Hemisphere. Wellington on a Plate isn't just a food festival - it's a gastronomic adventure spanning hundreds of restaurants, bars, and cafés, each showcasing creative limited-time dishes and cocktails.

You're not just eating your way through the city - you're on a mission to become a certified Wellington on a Plate Gastronaut. Your guide, Hēmi (a local hospitality veteran with stories for days), knows every secret menu item, every chef's inspiration, and every hidden gem worth discovering.

Can you explore five distinct culinary experiences, face your "flavor dragon," and earn the prestigious Gastronaut badge before the festival ends?

## The Dragon

**Internal Obstacle**: Food adventurousness - trying something completely outside comfort zone

**Dragon Moment**: Task 3 - Ordering and eating a dish with an ingredient you've never tried or actively avoid (like seafood for the seafood-averse, fermented foods, insects, organ meats, etc.)

**Dragon Support**: Hēmi will provide cultural context, preparation information, and encouragement. They'll also offer strategies for mindful tasting and reframing food anxiety.

## Quest Structure

### Task 1: The Classic Wellington Experience
**Objective**: Visit a traditional Wellington establishment and try their WoaP special  
**Challenge**: Navigate the festival, make booking, engage with experience  
**Verification**: Photo of dish + receipt/booking confirmation + brief review  
**Dragon**: Small - festival navigation and booking  

**NPC Dialogue** (Hēmi):
> "Kia ora, Gastronaut-in-training! Welcome to Wellington on a Plate - the best food event in Aotearoa! Your first mission: Experience a classic. I'm sending you to [Restaurant Name], a Wellington institution. They're doing a WoaP burger/dish that's getting rave reviews. Book a table (do it NOW - spots fill fast!), go enjoy, and tell me what you think. Pro tip: Chat with your server - ask what inspired the dish. The stories make the food taste better!"

### Task 2: The Hidden Gem Discovery
**Objective**: Find and try a WoaP offering at a venue you've never been to  
**Challenge**: Discovering new places, stepping outside familiar zones  
**Verification**: Photo + location check-in + "discovery story" (how you found it)  
**Dragon**: Small - exploring unfamiliar territory  

**NPC Dialogue** (Hēmi):
> "Good! But we're not doing the tourist trail. Time to find a hidden gem - a place you've never been, maybe didn't even know existed. Browse the WoaP guide, ask locals, follow your curiosity. Here's my challenge: Pick somewhere that makes you think 'huh, never noticed that place before.' Go there. Try something. Then tell me: What surprised you? How did you find it? This is how you become a real Gastronaut - by exploring, not just eating."

### Task 3: The Flavor Dragon Challenge
**Objective**: Try an ingredient or dish type you've been avoiding or never experienced  
**Challenge**: Confronting food fears or prejudices  
**Verification**: Photo + reflection on experience (honest, can include if didn't like it)  
**Dragon**: MAIN - food adventurousness and vulnerability  

**NPC Dialogue** (Hēmi):
> "Alright, this is where we get real. Every true Gastronaut has a 'flavor dragon' - an ingredient or dish type they avoid. Maybe it's seafood, maybe it's organ meat, maybe it's fermented foods, maybe it's just something super spicy or unusual. Your mission: Find a WoaP dish featuring YOUR dragon ingredient. Order it. Eat it mindfully. Here's the thing - you don't have to like it. You just have to try it with an open mind and curiosity. I'll be here to support you. Tell me your dragon, and I'll help you find the perfect challenge. Ready to be brave?"

**Post-Dragon Dialogue**:
> "E hoa! You did it! You faced your flavor dragon! How do you feel? Whether you loved it, tolerated it, or honestly didn't enjoy it - you tried something new. That's courage. That's growth. That's what separates tourists from Gastronauts. You just expanded your world a little bit. Celebrate this moment - you're braver than you think."

### Task 4: The Social Experience
**Objective**: Bring someone else to a WoaP experience and share the adventure  
**Challenge**: Creating shared memories and introducing others to quality  
**Verification**: Group photo + companion's brief reaction/review  
**Dragon**: None - spreading the joy  

**NPC Dialogue** (Hēmi):
> "You're becoming a proper Gastronaut! Now it's time to share the mana. Invite a friend, family member, or date to join you for a WoaP experience. Choose something you think they'd love - or something that would be an adventure for them too. The best meals are shared meals. Take them somewhere special, create a memory together, and report back. What did you choose? How did they react? Did you create a new Gastronaut?"

### Task 5: The Cocktail Adventure (or Non-Alcoholic Alternative)
**Objective**: Experience WoaP's cocktail competition or specialty beverage  
**Challenge**: Appreciating craft beverage as part of culinary culture  
**Verification**: Photo + tasting notes  
**Dragon**: Small - if uncomfortable in bar settings  

**NPC Dialogue** (Hēmi):
> "WoaP isn't just food - it's the whole beverage culture too! Your mission: Try one of the competition cocktails (or if you don't drink alcohol, find a specialty mocktail, coffee, or tea experience). Pay attention - what flavors do you taste? What's the story behind it? Good bartenders are artists too. Chat with them if you can. Learn something about the craft. Wellington's beverage scene is world-class - experience it properly!"

### Task 6: The Gastronaut Reflection & Ambassador Challenge
**Objective**: Reflect on journey and share recommendations publicly  
**Challenge**: Synthesizing experience and contributing to community  
**Verification**: Public post (social media/blog/video) + reflection document  
**Dragon**: None - celebration and sharing  

**NPC Dialogue** (Hēmi):
> "Congratulations, Gastronaut! You've completed your Wellington on a Plate journey. Now, the final mission: Share your wisdom. Write or record your reflections - what were your highlights? What surprised you? What did you learn about Wellington, food, or yourself? Then, share it publicly - post your top 3 WoaP recommendations for others. You're now part of the Gastronaut guild - help others discover the magic you found. Ka pai!"

## Rewards

### Primary Reward
**Wellington on a Plate Gastronaut Badge**
- Visual badge showing wellington harbor with stylized food/cocktail elements
- Metadata includes: number of venues visited, flavor dragon conquered, date of completion
- Shareable on social media with #WoaPGastronaut

### Secondary Rewards
- **Digital Passport**: Collectible stamps for each venue visited
- **Unlocks**: 
  - "Wellington Food Critic" quest (advanced)
  - "Regional Food Festival" quests (Hawke's Bay, Marlborough, etc.)
  - "Home Chef Challenge" (recreate WoaP dishes at home)
- **Partner Discounts**: Special offers from WoaP partner venues (if arranged)
- **Community**: Join Wellington Gastronaut community for year-round food events

### Intrinsic Rewards
- Expanded culinary horizons
- Overcame food anxieties or prejudices
- Discovered new favorite venues
- Created memorable experiences and stories
- Deeper appreciation for Wellington's food culture
- Confidence in exploring new cuisines

## Verification Method

**Tasks 1-5**: 
- Photo verification with GPS metadata during WoaP festival dates
- Receipt or booking confirmation
- NPC reviews written reflections for authenticity (not just "it was good")

**Task 6**: 
- Public post must be visible and verifiable
- Reflection document reviewed for thoughtfulness and learning

**Anti-Gaming Measures**:
- Photos must be original (reverse image search check)
- Timestamps must align with festival dates
- Reflections must demonstrate genuine engagement (NPC flags generic responses)
- Different venues required (can't claim same place 5 times)
- Dragon ingredient must be verified as legitimate challenge for that user

## Success Metrics

**Completion Rate Target**: 70% (allows for multi-week timeframe flexibility)  
**Average Duration**: 2-3 weeks across festival period  
**Dragon Success Rate**: 80% (most people push through with support)  
**User Satisfaction**: 4.8/5 stars (fun, social, rewarding)  
**Re-engagement**: 75% participate in next year's WoaP quest  

## Design Notes

### Why This Quest Works

1. **Tied to Real Event**: Leverages existing Wellington on a Plate infrastructure
2. **Flexible Timeframe**: 2-4 weeks allows scheduling around work/life
3. **Social Component**: Encourages shared experiences
4. **Authentic Challenge**: The flavor dragon is real psychological growth
5. **City Discovery**: Participants learn about Wellington beyond tourist spots
6. **Accessible**: Beginner-friendly with options at various price points
7. **Annual Re-engagement**: Can participate every year with different choices

### Scalability & Variations

**Other Food Festivals**:
- Visa Wellington on a Plate (official partnership opportunity)
- Auckland Restaurant Month
- Hawke's Bay Food & Wine
- Marlborough Wine & Food Festival
- Beervana, Bread & Circus, etc.

**Regional Adaptations**:
- Melbourne Food & Wine Festival
- Sydney Good Food Month
- International food festivals

**Price Accessibility**:
- Budget Gastronaut (cafés and affordable options)
- Standard Gastronaut (mix of price points)
- Luxury Gastronaut (fine dining focus)

### Partnership Opportunities

**Official WoaP Partnership**:
- Co-branded badges and recognition
- Featured on official WoaP website/materials
- Exclusive quest participant benefits
- Data sharing on venues/dishes popularity

**Restaurant Partners**:
- Featured venues get quest participant traffic
- Special "Gastronaut" menu markings
- Bonus rewards for completing quest at their venue

**Tourism Wellington**:
- Quest drives August visitation
- International visitor engagement
- Year-round Wellington food culture promotion

## Related Quests

**Prerequisites**: 
- None (beginner-friendly)
- Optional: "Wellington Food Explorer" (our earlier example quest)

**Unlocks**: 
- "Wellington Food Critic" (Advanced) - deeper analytical tasting
- "Home Chef: WoaP Edition" (Intermediate) - recreate dishes at home
- "Restaurant Week Explorer" - try other festival formats
- "Regional Food Trail" - expand to other NZ regions

**Part of Chain**: 
- New Zealand Food Festival Circuit (8 major events)
- Global Gastronaut Passport (international food events)
- Wellington Culture Series (food, arts, music, heritage)

## Special Considerations

### Dietary Restrictions
Hēmi adapts dragon challenge appropriately:
- Vegetarians: Try specific vegetables they avoid (Brussels sprouts, mushrooms, etc.)
- Vegans: Challenge around trying new plant-based proteins or preparations
- Allergies: Never suggest allergens; focus on flavor/preparation styles they avoid
- Religious restrictions: Fully respect and work within boundaries

### Budget Considerations
Quest can be completed at various price points:
- Affordable options exist across WoaP
- Hēmi suggests budget-friendly venues
- Task structure doesn't require expensive dining
- Optional "Budget Gastronaut" variant with specific price cap

### Accessibility
- Venues with wheelchair access noted
- Alternative tasks for those with mobility limitations
- Delivery/takeaway options count where appropriate
- Flexible timing within festival window

---

This quest transforms Wellington on a Plate from a fun food festival into a structured adventure that encourages genuine culinary exploration, personal growth, and deep engagement with Wellington's food culture.
