# Example Quest: The William Pike Award Journey

## Quest Overview

**Type**: Personal Development (Youth Award Program)  
**Duration**: 6-12 months  
**Difficulty**: Intermediate  
**Location**: New Zealand (various locations)  
**Age**: 14-19 years old  

## Narrative

The William Pike Challenge Award isn't just another school program - it's a rite of passage. Named after William Pike, a young New Zealander who overcame incredible adversity after losing his legs in a volcanic eruption on Mt. Ruapehu, this award challenges you to grow beyond what you thought possible.

You're not collecting ticks on a checklist. You're embarking on a year-long hero's journey across four domains: Outdoor Adventure, Community Service, Personal Development, and a Major Project. Each domain will test you differently. Together, they'll transform who you are.

Your mentor is Piki (Māori for "to climb"), a former Pike Award holder who remembers their own journey and knows exactly where the challenges lie. They'll guide you through each domain, celebrate your victories, and help you face your dragons.

Ready to become who you're capable of being?

## The Dragon

**Internal Obstacle**: Self-doubt about capabilities / comparing self to others / fear of not being "good enough"

**Dragon Moment**: The Major Project - committing to and completing a significant self-directed challenge that stretches you beyond your comfort zone over 3+ months.

**Dragon Support**: Piki provides project design guidance, milestone check-ins, troubleshooting help, and reframes struggles as proof of growth.

## Quest Structure

### Domain 1: Outdoor Adventure (25 hours minimum)
**Objective**: Complete outdoor activities that challenge physical abilities and build resilience  
**Challenge**: Pushing physical limits, facing outdoor fears  
**Verification**: Activity logs + supervisor signatures + photos/evidence  
**Dragon**: Medium - physical discomfort and fear  

**NPC Dialogue** (Piki):
> "Kia ora! Your Pike Award journey starts here - outside, in nature, pushing your limits. You need minimum 25 hours of outdoor adventure. This isn't casual walks - this is tramping, kayaking, rock climbing, mountain biking, camping, skiing, orienteering. Activities that make you think 'can I do this?' Your mission: Choose 4-5 outdoor activities. At least one should genuinely scare you a bit. Track every hour, get supervisor signatures, document with photos. Remember William Pike's story - he climbed mountains AFTER losing his legs. What's your mountain? Let's climb it together."

### Domain 2: Community Service (25 hours minimum)
**Objective**: Contribute meaningfully to your community through service  
**Challenge**: Sustained commitment to helping others  
**Verification**: Service logs + supervisor verification + impact reflection  
**Dragon**: Small - consistency and showing up  

**NPC Dialogue** (Piki):
> "Second domain: Give back. 25 hours minimum of community service. But here's the key: Don't just clock hours. Make IMPACT. Find something that matters to you. Environmental conservation? Coaching younger kids? Helping elderly? Supporting animals? Food banks? Whatever calls to you - commit deeply. The best service is when you forget you're 'doing service' and just care about the cause. Find your cause. Commit. Serve. Document the hours, yes, but more importantly: document the impact. How did your service matter? Who did it help? How did YOU change through serving?"

### Domain 3: Personal Development (4-6 activities)
**Objective**: Develop new skills or deepen existing ones through structured activities  
**Challenge**: Stepping outside comfort zones in various life areas  
**Verification**: Activity completion + skill demonstration + learning reflection  
**Dragon**: Medium - trying new things where you're not naturally good  

**NPC Dialogue** (Piki):
> "Third domain: Grow yourself. Pick 4-6 personal development activities from the Pike Award list - things like: first aid course, learning instrument, public speaking, cooking, budgeting, cultural learning, sport skills, art, whatever interests you. Here's the challenge: At least TWO should be things you're NOT naturally good at. That's where real growth happens. You're a natural athlete? Do a music course. You're a bookworm? Try rock climbing. Comfort zones are cozy but growth happens at the edges. Choose your activities. Commit. Learn. Prove you can develop skills through effort, not just talent."

### Domain 4: Major Project - THE DRAGON (3+ months)
**Objective**: Design and complete a significant self-directed project  
**Challenge**: Sustained effort on challenging goal with minimal external structure  
**Verification**: Project plan + progress logs + final presentation/evidence + reflection  
**Dragon**: MAIN - sustained self-direction and facing "not good enough" fears  

**NPC Dialogue** (Piki):
> "Here it is. Your Major Project. The dragon domain. This is where Pike Award holders are truly forged. Your mission: Design a 3+ month project that significantly challenges you. It could be: learning a language, writing a novel, creating a business, building something, mastering an art form, organizing a major event, creating a community program - whatever matters to YOU and stretches you. The requirements: 1) Sustained effort over 3+ months, 2) Documented progress, 3) Clear completion criteria, 4) Final presentation/showcase. Here's where the dragon lives: Around month 2, you'll want to quit. You'll think 'this is too hard,' 'I'm not good enough,' 'I should have picked something easier.' THAT'S THE DRAGON. That's self-doubt trying to protect you from failure by guaranteeing you never try. When that moment comes - and it will - message me immediately. We'll slay it together. What's your Major Project? Tell me what excites and terrifies you about it."

**Major Project Check-ins** (Monthly):
> "Month 1: How's the project going? What's been easier than expected? What's harder?"
> "Month 2: This is often the struggle month. How are you feeling? What wants you to quit? Tell me about your dragon."
> "Month 3: Final push! You can see the finish line. What do you need to complete strong?"

**Post-Dragon Dialogue**:
> "YOU DID IT! You completed your Major Project! Do you understand what that means? You sustained effort on a challenging goal for MONTHS. Most adults can't do that. You faced self-doubt and kept going. You proved you can finish hard things. Look at what you created/learned/achieved. This is forever. When life throws challenges at you later, remember: I completed my Pike Award Major Project. I can do hard things. I slay dragons. You're a William Pike Award holder now. That means something. Wear it with pride."

### Final Requirement: Integration & Presentation
**Objective**: Reflect on full journey and present to community  
**Challenge**: Synthesizing experience and sharing publicly  
**Verification**: Written reflection + presentation delivery + award ceremony attendance  
**Dragon**: Small - public sharing and vulnerability  

**NPC Dialogue** (Piki):
> "Final mission: Integration. You've completed four domains over 6-12 months. Now, make meaning from it. Write your reflection: Who were you when you started? Who are you now? What surprised you? What was hardest? What are you most proud of? Then, prepare your presentation - you'll share your journey with your community. Parents, teachers, fellow Pike holders, younger students. Tell your story. Share your dragons. Inspire others. Finally, attend your award ceremony. Receive your William Pike Challenge Award with pride. You earned it. You're now part of a fellowship of young people who chose growth over comfort. Welcome, Pike Award holder."

## Rewards

### Primary Reward
**William Pike Challenge Award (Official)**
- Nationally recognized youth achievement award
- Certificate and badge/pin
- Recognized by universities and employers
- Lifelong credential

### Quest Platform Reward
**Pike Award Hero Badge**
- Digital badge with four domain symbols
- Metadata: All activities completed, major project details, timeframe
- Special prestige designation on platform

### Secondary Rewards
- **NCEA Credits** (if in school program)
- **University Recognition** (mentioned in applications)
- **Community Recognition** (presentation and ceremony)
- **Unlocks**: Leadership awards, mentorship opportunities, advanced challenge programs
- **Network**: Join Pike Award holder alumni community

### Intrinsic Rewards
- Overcame sustained challenge over many months
- Developed diverse skills and experiences
- Contributed meaningfully to community
- Completed significant self-directed project
- Built resilience, confidence, and character
- Proven capability for sustained effort
- Identity shift: "I'm someone who finishes big things"

## Verification Method

**Official Pike Award Verification**:
- All activities logged in official Pike Award program
- Supervisor signatures required
- School/program coordinator oversight
- Official award criteria met

**Quest Platform Integration**:
- Sync with official Pike Award records
- Additional reflections and insights
- Enhanced documentation and storytelling
- Community sharing and celebration

## Success Metrics

**Completion Rate Target**: 75% (self-selected motivated youth)  
**Average Duration**: 9 months  
**Dragon Success Rate**: 85% (complete Major Project)  
**User Satisfaction**: 4.9/5 stars (transformative experience)  
**Long-term Impact**: Measurable in confidence, achievement, and future success  

## Design Notes

### Why This Quest Works

1. **Real Award Program**: Tied to established, respected New Zealand award
2. **Multi-Domain Growth**: Develops whole person, not just one area
3. **Age-Appropriate Challenge**: Designed specifically for teens
4. **Sustained Commitment**: Builds capacity for long-term effort
5. **Inspirational Foundation**: William Pike's story provides powerful context
6. **Community Recognition**: Public ceremony validates achievement
7. **Lasting Impact**: Shapes identity during formative years

### Partnership Opportunity

**William Pike Challenge Award Trust**:
- Official quest platform partnership
- Digital platform for modern youth
- Enhanced tracking and engagement
- Community building among participants
- Increased participation and completion rates
- Data insights for program improvement

## Related Quests

**Prerequisites**: None (entry-level for 14-19 year olds)

**Unlocks**:
- "Pike Award Gold" (advanced level)
- "Duke of Edinburgh Award" (international equivalent)
- "Youth Leadership Program" quests
- "University Prep" achievement track

**Part of Chain**:
- Youth Development & Achievement Series
- New Zealand Youth Awards Collection
- Character Building & Resilience Track

---

This quest transforms the William Pike Award from an excellent but sometimes overwhelming program into a guided journey with clear support, dragon identification, and celebration of the transformative potential of sustained youth challenge and achievement.
