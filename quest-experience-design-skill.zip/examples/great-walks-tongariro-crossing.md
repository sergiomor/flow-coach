# Example Quest: The Great Walk Tramper - Tongariro Alpine Crossing

## Quest Overview

**Type**: Experience-Based (Exploration - Outdoor Adventure)  
**Duration**: 6-8 hours hiking + 1-2 days preparation/travel  
**Difficulty**: Intermediate-Advanced  
**Location**: Tongariro National Park, New Zealand  

## Narrative

The Tongariro Alpine Crossing is consistently rated as one of the world's best single-day hikes - a 19.4km journey through an alien volcanic landscape that looks like it belongs on another planet. This isn't a gentle nature walk; this is a pilgrimage through one of New Zealand's most sacred and dramatic landscapes, a UNESCO World Heritage site that tells stories of fire, ice, and the Māori people.

Your guide is Rangi (named after the sky father), a tramping veteran who has walked this track over 50 times in all conditions. They know every rest stop, every weather sign, and every moment where the mountain tests your resolve. They'll help you prepare, encourage you through the tough sections, and ensure you experience the crossing as a transformative journey, not just a hike.

Can you complete the full crossing, honor the mountain, and earn your Great Walker badge?

## The Dragon

**Internal Obstacle**: Physical endurance / mental quitting during the hardest climb

**Dragon Moment**: The Red Crater ascent - the steepest, most brutal section of the climb, usually happening when you're already tired. This is where most people question why they're doing this and where the mental battle happens.

**Dragon Support**: Rangi will provide pre-climb mental preparation, real-time encouragement via pre-loaded voice messages triggered by GPS locations, and post-dragon celebration. Understanding that this moment is coming helps prepare for it.

## Quest Structure

### Task 0: Preparation - Know Before You Go (1-2 days before)
**Objective**: Complete thorough preparation including gear check, weather monitoring, transport booking, and physical readiness  
**Challenge**: Proper planning and not underestimating the challenge  
**Verification**: Preparation checklist completion + gear photos + transport bookings  
**Dragon**: Small - preparation discipline  

**NPC Dialogue** (Rangi):
> "Kia ora, future Great Walker! The Tongariro Alpine Crossing is one of New Zealand's greatest adventures - and also one that demands respect. Every year, unprepared people get rescued, injured, or worse. We're not going to let that be you. Your first quest tasks: 1) Complete the detailed preparation checklist I'm sending you. 2) Check the weather forecast - if it's severe, we reschedule. The mountain will be there another day. 3) Book your transport (shuttle to Mangatepopo, pickup from Ketetahi). 4) Send me photos of your gear - proper boots, layers, food, water, emergency supplies. 5) Do an honest self-assessment: Have you hiked 6-8 hours before? Do you have reasonable fitness? This isn't the time for false bravado. The mountain doesn't care about your ego. Show me you're ready, and we'll walk together."

### Task 1: Dawn Warrior - The Journey Begins (First 3km)
**Objective**: Start early, walk the initial valley section mindfully, reach the base of the climb  
**Challenge**: Early morning start, finding rhythm, patience in the easy section  
**Verification**: Time-stamped photos at Mangatepopo Saddle + reflection on morning mindset  
**Dragon**: Small - early rising, patience before challenge  

**NPC Dialogue** (Rangi):
> "It's go time! You should be starting between 6-7am - this gives you plenty of daylight. The first 3km is deceptively easy - boardwalks through tussock and small streams. Don't race. Find your pace. Breathe. Look around - you're walking between Tongariro and Ngauruhoe (Mt. Doom from Lord of the Rings!). This is sacred land. The mountain Tongariro is one of three volcanic peaks that are ancestors to the local iwi (tribe). Walk with respect. When you reach the Mangatepopo Saddle and look up at the climb ahead, take a moment. This is where your real journey begins. Photo, breathe, and let's climb."

### Task 2: The First Ascent - South Crater (Next 2.5km)
**Objective**: Complete the initial steep climb to South Crater  
**Challenge**: First test of endurance, altitude gain, loose rock  
**Verification**: Photo at South Crater with timestamp + exertion check-in  
**Dragon**: Medium - questioning if you can do this  

**NPC Dialogue** (Rangi - triggered at base of climb):
> "Here it is - the first real challenge. This is called the Devil's Staircase by some. Steep, rocky, relentless. Your legs will burn. You'll want to stop every few steps. That's normal. Here's the technique: small steps, steady breathing, regular micro-breaks. Don't compare yourself to faster hikers passing you. Your pace is your pace. Every step up is progress. The South Crater at the top is like landing on the moon - worth every burning muscle. You've got this. Climb strong."

**Dialogue at South Crater**:
> "Look at you! You've made it to South Crater. Take a moment. This volcanic plain is surreal, isn't it? Rest here. Drink water. Eat something. But I need to prepare you: the hardest part is next. The Red Crater ascent is brutal. It's where the mountain asks if you really want this. It's where your dragon waits. But here's the secret: you're already stronger than you think. That climb you just did? You did that. The Red Crater is just more of the same, just steeper. Rest up. We face the dragon soon."

### Task 3: THE RED CRATER - The Dragon Ascent (1km but feels like forever)
**Objective**: Complete the steep Red Crater ascent to the highest point of the crossing  
**Challenge**: The most physically and mentally demanding section  
**Verification**: Summit photo + voice note about the experience + dragon-slaying reflection  
**Dragon**: MAIN - physical exhaustion, mental doubt, wanting to quit  

**NPC Dialogue** (Rangi - triggered at Red Crater base):
> "This is it. Your dragon moment. This ascent is steep, loose, and relentless. Your legs are already tired. Your lungs will gasp for air. Doubt will creep in. The dragon will whisper: 'This is too hard. You can turn back. You don't need to prove anything.' But listen to me: Every single person who has earned the Great Walker badge has stood exactly where you're standing, feeling exactly what you're feeling. And they all made the choice to take the next step. Not the next hundred steps - just the next one. Then another. Then another. You don't have to be fast. You don't have to be graceful. You just have to keep moving forward. I'll check in with you partway up. Remember: the dragon doesn't want to fight. It wants you to quit. Don't let it win. You're a warrior. Climb."

**Midpoint Check** (GPS-triggered):
> "Still climbing? Good! Halfway there. Legs screaming? Yeah, that's normal. This is the crux. This is where mental toughness outweighs physical strength. Every step is a choice to keep going. You're doing it. Keep. Going."

**Post-Dragon Dialogue** (at summit):
> "WARRIOR! You did it! You're at the summit of Red Crater, the highest point of the Tongariro Alpine Crossing. Do you feel that? That's not just altitude - that's VICTORY. You just slayed your dragon. Look around - the view is your trophy. The Emerald Lakes below, the crater to your right, the volcanic landscape stretching in every direction. This moment - breathe it in. You earned this. You are stronger than your doubt. You are more capable than your fear. Remember this forever. Now, record a voice note - tell yourself how you feel right now. You'll want to listen to this when life gets hard again. You're a Great Walker now."

### Task 4: The Emerald Lakes & Blue Lake - Beauty & Recovery (Next 3km)
**Objective**: Descend to and appreciate the emerald lakes, reach Blue Lake  
**Challenge**: Steep descent, maintaining focus when tired, staying present  
**Verification**: Photos of both lakes + reflection on post-dragon feelings  
**Dragon**: Small - maintaining awareness when exhausted  

**NPC Dialogue** (Rangi):
> "Now comes your reward. The descent to the Emerald Lakes is steep but short. These lakes - their color comes from minerals leached from thermal areas. They're stunning, but also sacred (tapu) - don't touch the water. Photograph, appreciate, but respect. Then onward to Blue Lake, which is even more sacred - an explosion crater that's now pristine water. This is where the mountain gives back after testing you. Walk slowly. You've slayed the dragon. Everything from here is celebration. How does your body feel? How does your spirit feel? That's the difference between before and after facing your dragon."

### Task 5: The Long Walk Out - Endurance & Reflection (Final 12km)
**Objective**: Complete the final descent through native bush to Ketetahi  
**Challenge**: Maintaining energy and knee strength on long descent  
**Verification**: Final checkpoint photo + completion reflection  
**Dragon**: Small - persistence when tired  

**NPC Dialogue** (Rangi):
> "The final stretch. It's mostly downhill now, through stunning native bush. Your knees might protest. Your feet might ache. That's fine - you've earned every ache. Use this time to reflect on your journey. You started as someone who hadn't completed the crossing. Now you're hours from being someone who has. That's transformation. What did you learn about yourself today? What surprised you? How did you push through the hard parts? This descent is your integration time - processing the experience. Finish strong, Great Walker."

### Task 6: Celebration & Integration (After finishing)
**Objective**: Immediate post-walk celebration, then deeper reflection and learning capture  
**Challenge**: Moving from physical achievement to integrated wisdom  
**Verification**: Celebration photo + detailed reflection document + commitment  
**Dragon**: None - pure celebration  

**NPC Dialogue** (Rangi):
> "E te toa! You've completed the Tongariro Alpine Crossing! You walked 19.4 kilometers. You climbed 760 meters. You descended 1120 meters. You faced your dragon on Red Crater and won. You've earned the Great Walker badge. Now, three final tasks: 1) Celebrate immediately - you deserve it. Treat yourself well tonight. 2) Within 24 hours, complete your full reflection - what did you learn? How did you grow? What will you carry forward? 3) Make a commitment - what's your next Great Walk? Because once you've tasted this, you'll want more. Welcome to the fellowship of Great Walkers. The mountains are calling, and you've proven you can answer."

## Rewards

### Primary Reward
**Great Walker: Tongariro Badge**
- Visual badge showing Red Crater and Emerald Lakes with GPS track outline
- Metadata: Date completed, time taken, weather conditions, dragon conquered
- Part of the Great Walks of NZ collection (9 total badges)

### Secondary Rewards
- **Digital Trail Map**: Personal GPS track and elevation profile
- **Completion Certificate**: Official Tongariro Alpine Crossing completion
- **Unlocks**:
  - Other Great Walks quests (Milford, Routeburn, Kepler, etc.)
  - "Multi-Day Tramper" quest series
  - "Te Araroa - The Long Pathway" epic quest
  - "Great Walker: International" (famous hikes worldwide)
- **Community**: Join Great Walkers NZ community
- **Privileges**: Early booking access for multi-day Great Walks (if partnered with DOC)

### Intrinsic Rewards
- Conquered one of NZ's toughest day hikes
- Proved physical and mental resilience
- Connected deeply with nature and sacred landscape
- Overcame the Red Crater dragon
- Stories and photos to last a lifetime
- Confidence for bigger challenges
- Body-mind integration and strength

## Verification Method

**Preparation**: Checklist completion + gear photos  
**During Walk**: GPS tracking (with permission) + time-stamped photos at key points  
**Red Crater Summit**: Photo and voice recording with GPS data  
**Completion**: Final checkpoint + transport pickup confirmation  
**Reflection**: Document depth and authenticity reviewed by Rangi  

**Anti-Gaming Measures**:
- GPS tracking verifies actual walk (can't fake location)
- Photo timestamps must align with realistic walking times
- Weather conditions must match actual day (validates timing)
- Transport booking confirms date
- Rangi reviews for authentic vs. generic reflections
- Ranger/transport company partnerships can verify completion

## Success Metrics

**Completion Rate Target**: 85% (most who start, finish - but solid prep filters out unready)  
**Average Duration**: 7-8 hours walking time  
**Dragon Success Rate**: 90% (with proper prep and mental framing)  
**User Satisfaction**: 4.9/5 stars (life-changing experience)  
**Safety Record**: 100% (no incidents due to poor preparation)  

## Design Notes

### Why This Quest Works

1. **Real Challenge**: The Tongariro Crossing is genuinely hard - earning the badge means something
2. **Preparation Emphasis**: Reduces safety risks and increases success rates
3. **Dragon Location**: Red Crater is a known, documented struggle point for all hikers
4. **Sacred Context**: Respects Māori cultural significance of the mountain
5. **Transformation Focused**: Not just about finishing, but about who you become
6. **Scaffolded Support**: Rangi provides progressive support matched to difficulty
7. **Integration**: Reflection ensures experience becomes wisdom, not just achievement

### Safety Considerations (Critical)

**Weather**:
- Quest includes mandatory weather check 24hrs and morning-of
- Automatic quest postponement in dangerous conditions
- No penalties for weather-related cancellations

**Physical Readiness**:
- Self-assessment questionnaire before booking
- Recommended training program provided
- Clear fitness expectations set

**Gear Requirements**:
- Mandatory gear checklist verification
- Emergency equipment required
- Seasonal variations (winter requires alpine gear)

**Emergency Protocols**:
- Emergency contact information collected
- PLB (Personal Locator Beacon) rental encouraged
- Clear instructions for getting help if needed
- Rangi provides emergency resources

### Partnership Opportunities

**Department of Conservation (DOC)**:
- Official quest partnership
- Aligned with "Leave No Trace" principles
- Support for conservation efforts
- Crowd management (encourage off-peak walking)

**Transport Providers**:
- Integrated booking with shuttle companies
- Verification partnerships
- Bundle deals

**Gear Retailers**:
- Gear rental partnerships
- Discount codes for quest participants
- Proper gear education

**Tourism Organizations**:
- Tourism Central North Island
- Ruapehu Tourism
- International visitor engagement

### Scaling to Other Great Walks

This quest template adapts to all 10 Great Walks:
- **Day Walks**: Tongariro (done), Whanganui Journey (canoe)
- **Multi-Day**: Milford, Routeburn, Kepler, Abel Tasman, Heaphy, Rakiura, Paparoa, Lake Waikaremoana

**Multi-Day Quest Variations**:
- Extended preparation requirements
- Multiple dragon moments
- Hut community interactions
- Gear management and camp craft
- Extended reflection and integration

## Related Quests

**Prerequisites**: 
- "Day Hiker" (Beginner) - build foundational skills
- "Fitness Foundations" (Beginner) - ensure adequate conditioning

**Unlocks**: 
- "Great Walker: Milford Track" (5-day advanced quest)
- "Great Walker: Routeburn" (3-day intermediate)
- All 10 Great Walks quests
- "Te Araroa - The Long Pathway" (3000km epic quest)
- "Great Walker: International" (Inca Trail, Everest Base Camp, etc.)

**Part of Chain**: 
- Great Walks of New Zealand (complete all 10)
- Outdoor Adventurer Series
- Physical Challenge & Mastery track

## Environmental & Cultural Stewardship

**Leave No Trace**:
- Mandatory education on principles
- Carry out all rubbish
- Stay on marked tracks
- Respect wildlife

**Cultural Respect**:
- Understand tapu (sacred) status of some areas
- Don't touch lakes
- Learn about Māori relationship with the mountain
- Walk with respect and humility

**Conservation Support**:
- Optional donation to DOC conservation projects
- Information about volunteer opportunities
- Understanding of ecological significance

---

This quest transforms the Tongariro Alpine Crossing from a bucket-list tick-box into a genuine hero's journey with proper preparation, meaningful challenge, and authentic transformation. The dragon moment on Red Crater is real, documented, and universal to all who walk this track - making it the perfect crucible for growth.
