# Example Quest: The Sales Warrior's Path - Monthly Challenge

## Quest Overview

**Type**: Work-Based (Sales Performance Gamification)  
**Duration**: 1 month (recurring monthly)  
**Difficulty**: Intermediate  
**Location**: Any workplace (virtual or office)  

## Narrative

Sales isn't just about hitting numbers - it's about mastery, strategy, and continuous improvement. This month, you're not just "trying to make quota" - you're on the Sales Warrior's Path, a structured journey that transforms daily grind into an epic quest for professional excellence.

Your coach is Maven (named for expert knowledge), a sales veteran who has mastered every stage of the funnel and knows that top performers succeed through consistent excellence in fundamentals, not just hustle. They'll guide you through five pillars of sales mastery, each with specific challenges that build your skills while driving results.

Will you complete the Sales Warrior's Path this month and prove you're not just hitting quota, but mastering the craft?

## The Dragon

**Internal Obstacle**: Fear of rejection / call reluctance / avoiding difficult conversations

**Dragon Moment**: The "Uncomfortable Conversation" challenge - making 5 calls to leads who have previously said "not interested" or following up on stalled deals where you fear rejection.

**Dragon Support**: Maven provides scripts, reframing techniques, and celebrates each attempt (not just successes). Focuses on process over outcome.

## Quest Structure

### Task 1: Prospecting Power (Week 1)
**Objective**: Add 25 new qualified leads to your pipeline  
**Challenge**: Consistent daily prospecting despite other demands  
**Verification**: CRM entries + qualification notes  
**Dragon**: Small - prospecting discipline  

**NPC Dialogue** (Maven):
> "Welcome, Sales Warrior! Your first quest this month: Feed your pipeline. Great salespeople aren't great because they're lucky - they're great because they prospect consistently. Your mission: Add 25 new QUALIFIED leads this week. Not just names - qualified means you've verified: 1) They fit your ICP, 2) There's a potential need, 3) You have a contact path. Track them in the CRM with clear notes. Pro tip: Block 1 hour daily for prospecting. Protect this time like your paycheck depends on it - because it does. Report back Friday with your 25. Let's build your empire."

### Task 2: Connection Master (Week 2)
**Objective**: Have 15 meaningful conversations with prospects (calls/meetings)  
**Challenge**: Quality conversations, not just quick pitches  
**Verification**: Meeting logs + conversation quality notes  
**Dragon**: Medium - making time for real connection  

**NPC Dialogue** (Maven):
> "Week two: Deepen connections. Your mission: 15 meaningful conversations with prospects. Not voicemails. Not emails. Real conversations where you LISTEN. Here's your framework: Ask 3 questions before pitching anything. Understand their world. Find their pain. The best sales warriors are the best listeners. Quality metric: Can you summarize their key challenge in one sentence? If not, you didn't listen well enough. Chase quality, not just quantity. Report back: What themes are you hearing? What's surprising you?"

### Task 3: The Dragon - Uncomfortable Conversations (Week 2-3)
**Objective**: Make 5 courage calls - re-engaging cold/stalled leads  
**Challenge**: Facing rejection and persisting anyway  
**Verification**: Call logs + honest reflection on experience  
**Dragon**: MAIN - fear of rejection and "no"  

**NPC Dialogue** (Maven):
> "Time to face your dragon. Every sales warrior has leads in their CRM that they're avoiding. The ones who said 'not now' or went cold. The deals that stalled. Your dragon mission: Call 5 of them this week. Re-engage. Here's the reframe: They already said no or ghosted - what do you have to lose? The worst that happens is... the same as if you didn't call. But the best that happens? You resurrect a dead lead. You learn why they really said no. You build courage muscle. I'm giving you three opening scripts to choose from. Pick one. Practice it. Then just dial. Record how each call goes - not just the outcome, but how YOU felt. Rejection is just data. It can't hurt you unless you let it. You're braver than you think. Make the calls."

**Post-Dragon Dialogue**:
> "Look at you! Five courage calls completed! How do you feel? Let me tell you what you just proved: You can do uncomfortable things. Most sales reps avoid these calls forever. You faced them. That's warrior energy. Bet you learned something too - what did they say? Why did they really go cold? This intelligence makes you better. Even if all five said no again, you exercised your courage muscle. Next month, it'll be easier. You just leveled up."

### Task 4: Close Strong (Week 3-4)
**Objective**: Move 3 deals to next stage OR close 2 deals  
**Challenge**: Converting conversations to commitments  
**Verification**: CRM stage updates + deal value  
**Dragon**: Medium - asking for the commitment  

**NPC Dialogue** (Maven):
> "Week three and four: Close strong. Your mission: Move 3 deals forward to next stage, OR close 2 deals. Time to convert your efforts into results. Here's the warrior mindset: Asking for the business isn't pushy - it's service. If your product truly helps them, you OWE it to them to ask. Use clear asks: 'Are you ready to move forward?' 'What would you need to see to make a decision?' 'Can we get this scheduled?' Commit to asking clearly, then track what happens. Every yes and every no teaches you something. Let's close strong."

### Task 5: Master Reflection (End of Month)
**Objective**: Complete sales performance analysis + skill development plan  
**Challenge**: Honest self-assessment and commitment to growth  
**Verification**: Analysis document + next month's growth goals  
**Dragon**: None - strategic reflection  

**NPC Dialogue** (Maven):
> "Warrior, you've completed a month on the Sales Path! Now the most important task: Learn from it. Your final mission: Complete your performance analysis. Numbers: What hit? What missed? Why? Activities: Where did you excel? Where did you slack? Skills: What got easier? What's still hard? Dragon moment: How did facing rejection change you? Then, set 3 specific skill development goals for next month. Not just 'sell more' - real skills. Maybe it's asking better questions, or handling objections, or time management. Make them specific. This reflection is what separates good from great. Most sales reps just chase next month. Warriors learn, adapt, and improve. Document it. Share it with your manager if appropriate. Then, enroll in next month's quest. The path never ends - mastery is a journey, not a destination."

## Rewards

### Primary Reward
**Sales Warrior: [Month] Badge**
- Visual badge showing warrior shield with sales graph arrow
- Metadata: Leads added, meetings held, deals progressed, dragon conquered
- Stackable: Earn 12 for full year mastery

### Secondary Rewards
- **Leaderboard Recognition** (optional competitive element)
- **Company-Specific Rewards**: Gift cards, extra PTO, team lunch, etc. (if company partners)
- **Unlocks**:
  - "Sales Manager Track" quests (leadership development)
  - "Advanced Negotiation" quest
  - "Sales Master" status (after 6 consecutive months)
- **Skill Badges**: Separate micro-badges for each pillar mastered

### Intrinsic Rewards
- Improved sales skills and confidence
- Overcame call reluctance and rejection fear
- Better pipeline management discipline
- Stronger relationships with prospects
- Increased closing effectiveness
- Professional growth and mastery

### Financial Rewards
- Commissions from closed deals
- Potential bonuses (company-specific)
- Increased earnings from improved performance

## Verification Method

**CRM Integration**:
- Automatic data pull from CRM (Salesforce, HubSpot, etc.)
- Validates lead additions, meeting logs, deal progressions
- Verifies completion of activities

**Self-Reporting with Verification**:
- Dragon calls logged with honest notes
- Maven reviews for authenticity (not just "made 5 calls")
- Reflection document reviewed for depth

**Manager Confirmation** (Optional):
- Manager can verify completion and quality
- Adds credibility to badge
- Provides coaching opportunity

**Anti-Gaming Measures**:
- CRM data validates claimed activities
- Quality thresholds (not just quantity)
- Maven flags suspicious patterns (all calls 1 minute long, etc.)
- Random spot checks on reflection authenticity

## Success Metrics

**Completion Rate Target**: 60% (monthly recurrence requires discipline)  
**Performance Improvement**: 15-30% increase in key metrics vs. non-participants  
**Dragon Success Rate**: 70% (with proper support)  
**User Satisfaction**: 4.3/5 stars (work-based so inherently less "fun")  
**Retention Rate**: 75% complete 3+ consecutive months  

## Design Notes

### Why This Quest Works

1. **Structures Daily Work**: Transforms routine tasks into meaningful progression
2. **Skill Development Focus**: Not just about numbers, about getting better
3. **Manageable Chunks**: Weekly missions prevent overwhelm
4. **Addresses Real Fear**: Call reluctance is genuine obstacle for salespeople
5. **Recognition**: Public badges give prestige beyond commission
6. **Recurring Model**: Monthly structure builds habits and continuous improvement
7. **Manager-Friendly**: Aligns with company goals and metrics

### Corporate Partnership Model

**For Sales Organizations**:
- White-label the quest platform
- Customize badges with company branding
- Integrate with existing CRM
- Add company-specific rewards
- Manager dashboard for monitoring
- Team challenges and competitions
- Revenue sharing or platform fee model

**Benefits to Company**:
- Increased sales performance
- Better activity metrics
- Reduced call reluctance
- Gamified motivation
- Lower turnover (more engaging work)
- Clear skill development pathways
- Team culture and friendly competition

### Scalability

**Different Sales Types**:
- B2B Enterprise Sales (longer cycles, higher value)
- B2C Retail Sales (higher volume, shorter cycles)
- Inside Sales (phone/digital focused)
- Field Sales (in-person meetings)
- Account Management (expansion vs. new business)

**Different Industries**:
- SaaS/Tech sales
- Financial services
- Real estate
- Retail
- Insurance
- Manufacturing

**Different Team Sizes**:
- Individual contributors
- Small teams (competitive elements)
- Large sales organizations (divisions compete)

### Integration Requirements

**Technical**:
- CRM API connections (Salesforce, HubSpot, Pipedrive, etc.)
- SSO for corporate accounts
- Manager dashboards
- Reporting and analytics
- Mobile app for on-the-go logging

**Organizational**:
- Manager training on supporting quests
- Alignment with compensation plans
- Clear expectations and policies
- Recognition in team meetings
- Integration with performance reviews

## Related Quests

**Prerequisites**: 
- "Sales Fundamentals" (Beginner) - if new to sales
- None (can start immediately for experienced reps)

**Unlocks**: 
- "Sales Manager: First 90 Days" (Leadership)
- "Advanced Negotiation Master" (Expert skill)
- "Sales Master" (after 6 consecutive months)
- "Revenue Champion" (annual recognition)

**Part of Chain**: 
- Monthly Sales Warrior Path (12-month track)
- Sales Professional Development Series
- Revenue Team Excellence program

## Team & Competition Variants

**Team Quest Mode**:
- Sales teams complete collectively
- Combined metrics for badge
- Encourages collaboration and support
- Shared celebration

**Competition Mode**:
- Individual leaderboards
- Weekly/monthly winners
- Friendly rivalry
- Bonus rewards for top performers

**Mentorship Mode**:
- Experienced reps mentor newcomers
- Both earn badges for success
- Knowledge transfer
- Culture building

---

This quest transforms daily sales activities from "hitting numbers" into a structured journey of skill mastery, with specific support for the psychological challenges (call reluctance, rejection fear) that limit many salespeople's success. The monthly recurring model builds sustainable habits and continuous improvement.
