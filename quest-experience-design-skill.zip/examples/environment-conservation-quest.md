# Example Quest: The Kaitiaki - Environmental Guardian

## Quest Overview

**Type**: Charitable Service (Environmental)  
**Duration**: 3 months (seasonal)  
**Difficulty**: Beginner-Intermediate  
**Location**: Local conservation areas  

## Narrative

Kaitiaki is the Māori concept of guardianship - caring for the environment as if you're responsible for it. Not just for yourself, but for future generations. You're not "volunteering for the environment" - you're becoming a guardian of your local ecosystem.

Your mentor is Tiaki (from kaitiaki), an environmental educator who has seen the transformation that happens when people move from "caring about" nature to actively protecting it.

This quest: Complete 40 hours of hands-on environmental conservation work and become a certified Kaitiaki.

## The Dragon

**Obstacle**: Feeling like individual actions don't matter  
**Dragon Moment**: Week 6 - seeing limited visible results, questioning impact  
**Support**: Tiaki reframes with long-term perspective, shows cumulative impact data, connects to larger movement  

## Quest Structure (Abbreviated)

### Task 1: Ecosystem Education
Learn about your local ecosystem, threats, and conservation priorities  

### Task 2: Native Planting (15 hours)
Plant 50+ native trees/plants in restoration areas  

### Task 3: Pest Trapping (10 hours)
Learn and maintain predator traps protecting native species  

### Task 4: The Dragon - Beach/River Cleanup (10 hours)
Lead or participate in cleanup events despite feeling small impact  
**Dragon**: "What difference does this really make?"  

### Task 5: Citizen Science (5 hours)
Contribute to biodiversity monitoring or environmental data collection  

### Task 6: Advocate & Inspire
Share journey publicly, recruit 2 others to conservation work  

## Rewards

- **Kaitiaki Environmental Guardian Badge**
- **Conservation Group Membership**
- **Species you helped protect** (specific native birds/plants)
- **Carbon offset credits** (for plantings)
- **Unlocks**: Advanced conservation quests, specialized tracks

## Why This Quest Works

1. Hands-on environmental action
2. Māori cultural concept provides meaning
3. Addresses "does it matter?" dragon  
4. Visible impact over time
5. Community building
6. Multiplier effect (inspiring others)
7. Connects to global movement

---

**Variants**: Marine conservation, urban ecology, wildlife protection, climate action
