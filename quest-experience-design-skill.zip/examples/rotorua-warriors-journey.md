# Example Quest: The Rotorua Warrior's Journey

## Quest Overview

**Type**: Experience-Based (Adventure - Cultural & Natural)  
**Duration**: 2-3 days  
**Difficulty**: Intermediate  
**Location**: Rotorua, New Zealand  

## Narrative

Rotorua is a land of fire and water, where the earth breathes steam and ancient forests whisper stories of the Māori people. You're not here as a tourist snapping photos - you're here as a warrior-in-training on a journey that will test your courage, teach you respect, and connect you to the living heart of Aotearoa.

Your guide is Kahu (named after the native hawk), a local Māori cultural advisor who knows both the sacred sites and the adrenaline rushes. They'll lead you through four elemental challenges - Earth, Water, Fire, and Spirit - each designed to push your boundaries and deepen your understanding.

Will you complete the warrior's journey and earn the respect of the land and its people?

## The Dragon

**Internal Obstacle**: Fear of physical challenges / stepping outside comfort zone in unfamiliar cultural contexts

**Dragon Moment**: The physical adventure challenge (ziplining/luge/rafting) where fear of heights, speed, or water confronts participants

**Dragon Support**: Kahu provides cultural context (warriors face fear with honor), safety assurance, and encouragement to push through discomfort with respect and courage.

## Quest Structure

### Task 0: Te Ao Māori - Cultural Preparation
**Objective**: Learn basic Māori protocols and the history of Rotorua before adventures begin  
**Challenge**: Engaging respectfully with unfamiliar culture  
**Verification**: Complete cultural learning module + reflection quiz  
**Dragon**: Small - humility and openness to new cultural frameworks  

**NPC Dialogue** (Kahu):
> "Kia ora, warrior-in-training. Before we begin your journey through Rotorua, you must understand: this land is sacred to Māori people. The geothermal activity you'll see isn't just science - it's the breath of Ruaumoko, god of earthquakes and volcanoes. The forests aren't just pretty - they're taonga, treasures. I need you to complete this cultural learning module. Learn the basic greetings, understand the concept of manaakitanga (hospitality) and kaitiakitanga (guardianship). Learn why we do hongi (pressing noses in greeting) and why certain places are tapu (sacred). This isn't about being politically correct - it's about showing respect to the land and people who will host your journey. Complete this with an open heart."

### Task 1: Earth Challenge - Whakarewarewa Forest Walk
**Objective**: Complete a solo forest walk through Redwood Memorial Grove, engage mindfully with nature  
**Challenge**: Slowing down, being present, forest walking meditation  
**Verification**: Specific forest photo checkpoints + mindfulness reflection  
**Dragon**: Small - modern pace vs. slow observation  

**NPC Dialogue** (Kahu):
> "Your first element: Earth. Whakarewarewa Forest - the Redwoods. These trees were planted over 100 years ago, and now they stand as giants. Your mission: Walk the trail I'm marking for you. But this isn't a fitness march - this is a meditation. I want you to go alone. Walk slowly. Touch the trees. Smell the earth. Listen to the birdsong. Find three moments of stillness where you stop and truly see. Take photos at the checkpoints, yes, but more importantly: connect. The forest has much to teach warriors about patience, strength, and growth. Report back: what did you notice? What did the forest say to you?"

### Task 2: Water Challenge - Thermal Experience
**Objective**: Experience Rotorua's geothermal waters through hot pools and/or mud bath  
**Challenge**: Surrendering to unfamiliar sensations, trusting the healing process  
**Verification**: Photo + sensory experience description  
**Dragon**: Small - unfamiliar sensations, semi-public bathing  

**NPC Dialogue** (Kahu):
> "Second element: Water. But this is water like you've never experienced - water heated by the earth's fire, water that heals. Your mission: Visit the thermal pools [specific location provided]. Not just a quick dip - I want you to spend at least 30 minutes experiencing it properly. Start in the cooler pools, gradually work to the hotter ones. Try the mud if available - yes, you'll look ridiculous, but warriors aren't afraid of looking silly in service of healing. Close your eyes. Feel how the heat penetrates your muscles. This water has been used for healing for centuries. What does it teach you about surrender and receiving?"

### Task 3: Fire Challenge - The Physical Adventure (DRAGON)
**Objective**: Complete an adrenaline activity that genuinely challenges your comfort zone  
**Challenge**: Confronting fear of heights/speed/unknown  
**Verification**: Activity booking receipt + photo/video evidence + courage reflection  
**Dragon**: MAIN - physical fear and comfort zone expansion  

**NPC Dialogue** (Kahu):
> "Third element: Fire. This is your dragon moment, warrior. Fire is energy, action, courage. Your mission: Choose an activity that genuinely scares you a bit. Not terrifies you - but challenges you. The options: Zipline through the forest canopy, ride the Luge at speed, white water raft the Kaituna River (includes a 7-meter waterfall drop), mountain bike the challenging trails, or the Velocity Valley adrenaline activities. Here's the key: Pick something that makes your stomach flutter when you think about it. That flutter? That's the dragon whispering 'stay safe, stay small.' But warriors grow by facing fear with courage. I'll be with you in spirit. Safety equipment and professionals will protect your body. Your job: Protect your warrior spirit by not letting fear win. You can do this. Tell me: which challenge calls to you? What makes you nervous about it?"

**Post-Dragon Dialogue**:
> "WARRIOR! You did it! How do you feel right now? That rush, that relief, that pride - that's what it feels like to slay your dragon. You just proved to yourself that you're braver than you thought. Did you know that Māori warriors would face much greater challenges to prove their courage? You just honored that tradition. This moment - remember it. When life asks you to be brave again, you'll remember: I faced my dragon in Rotorua, and I won. Ka mau te wehi! You are mighty!"

### Task 4: Spirit Challenge - Cultural Experience
**Objective**: Attend a traditional Māori cultural performance and hāngi feast  
**Challenge**: Engaging authentically with unfamiliar cultural practices  
**Verification**: Booking confirmation + cultural learning reflection  
**Dragon**: Small - cultural vulnerability and openness  

**NPC Dialogue** (Kahu):
> "Final element: Spirit. This is where we bring it all together. You've connected with earth, water, and fire. Now you'll connect with the spirit of the people. Your mission: Attend a traditional cultural performance and hāngi feast. This isn't entertainment - this is transmission of culture. When the warriors do the haka, feel the power. When they share the pūrākau (stories), really listen. When you do the hongi greeting, understand you're sharing breath with another person - connecting spirits. Taste the hāngi food and appreciate that it was cooked in the earth itself. Come with humility and openness. After, I want you to reflect: What moved you? What did you learn about Māori culture? What resonated with your own spirit?"

### Task 5: Integration - The Warrior's Return
**Objective**: Create integration plan for bringing lessons home  
**Challenge**: Translating experience into life changes  
**Verification**: Personal integration document + public sharing commitment  
**Dragon**: None - reflection and commitment  

**NPC Dialogue** (Kahu):
> "E te toa, warrior. You have completed your journey through all four elements. You've walked with respect through sacred forests, surrendered to healing waters, faced your dragon with courage, and opened your spirit to our culture. But the hero's journey doesn't end when the adventure ends - it ends when you bring the lessons home. Your final task: Tell me three specific ways this journey will change how you live. Maybe it's more courage in your career. Maybe it's more respect for nature. Maybe it's more openness to other cultures. Write them down. Commit to them. Then share your warrior story publicly - not to boast, but to inspire others to face their own dragons. Kia kaha, kia māia, kia manawanui - be strong, be brave, be steadfast. You are a warrior now."

## Rewards

### Primary Reward
**Rotorua Warrior Badge**
- Visual badge showing four quadrants (earth, water, fire, spirit) with Māori design elements
- Metadata includes: specific activities completed, dragon faced, cultural understanding demonstrated
- Respectfully designed with cultural consultation

### Secondary Rewards
- **Warrior's Certificate**: Formal recognition of completing the four-element journey
- **Unlocks**:
  - "Great Walks of New Zealand" quest series
  - "Māori Cultural Deep Dive" advanced quest
  - "Adventure Warrior" international quest chain
  - "Te Araroa Trail" epic quest
- **Partner Benefits**: Discounts at Rotorua adventure providers (if partnered)
- **Cultural Connection**: Introduction to ongoing Māori cultural learning resources

### Intrinsic Rewards
- Conquered physical fear
- Deepened cultural understanding and respect
- Connection to nature and place
- Personal courage and growth
- Authentic stories and memories
- Expanded worldview
- Body and spirit integration

## Verification Method

**Cultural Preparation**: Completion certificate from learning module  
**Forest Walk**: GPS-tracked route + checkpoint photos + reflection quality  
**Thermal Experience**: Photo with timestamp + sensory description  
**Adventure Challenge**: Activity provider confirmation + photo/video + reflection depth  
**Cultural Experience**: Venue confirmation + cultural learning demonstrated  
**Integration**: Document quality + public post verification  

**Anti-Gaming Measures**:
- Activity bookings verified with providers
- Photos require original metadata
- Cultural reflections reviewed for genuine understanding (not stereotypes)
- Kahu (NPC) flags superficial or disrespectful responses
- Must complete activities in sequence (can't skip cultural prep)

## Success Metrics

**Completion Rate Target**: 65% (intermediate difficulty)  
**Average Duration**: 2.5 days  
**Dragon Success Rate**: 75% (with proper support and choice of activity)  
**User Satisfaction**: 4.8/5 stars (transformative experience)  
**Cultural Sensitivity Score**: 95%+ (measured through reflection quality)  

## Design Notes

### Why This Quest Works

1. **Holistic Design**: Integrates physical, cultural, and reflective elements
2. **Respectful Cultural Integration**: Māori culture treated as central, not decorative
3. **Flexible Dragon**: Multiple adventure options accommodate different fears
4. **Authentic Transformation**: Combines outer adventure with inner growth
5. **Proper Sequencing**: Cultural preparation comes first, showing respect
6. **Integration Focus**: Doesn't end with completing activities - requires applying lessons

### Cultural Sensitivity Considerations

**Critical Requirements**:
- Māori cultural consultants review all content
- Language and concepts used accurately and respectfully
- Sacred sites and protocols properly acknowledged
- NPC (Kahu) represents authentic Māori perspective
- Quest promotes understanding, not appropriation
- Revenue sharing with Māori cultural providers where appropriate

**What This Quest Doesn't Do**:
- Treat culture as entertainment
- Use sacred symbols casually
- Reduce Māori culture to stereotypes
- Allow disrespectful behavior
- Claim authority on Māori culture (we provide learning pathways)

### Partnership Opportunities

**Rotorua Tourism**:
- Official destination partnership
- Featured experience pathway
- International visitor engagement

**Activity Providers**:
- Velocity Valley, Skyline Rotorua, Kaituna Cascades, Rotorua Canopy Tours
- Integrated booking and verification

**Cultural Experience Providers**:
- Mitai Māori Village, Tamaki Māori Village, Te Puia, Whakarewarewa Living Village
- Authentic cultural transmission partnerships

**Conservation Groups**:
- Forest restoration participation options
- Kaitiakitanga (guardianship) learning and action

## Related Quests

**Prerequisites**: 
- "Cultural Respect 101" (Beginner) - basic understanding of Māori culture
- Optional: "Outdoor Basics" if adventure activities are very unfamiliar

**Unlocks**: 
- "Great Walks of New Zealand" series (9 multi-day treks)
- "Māori Language Learner" (language acquisition quest)
- "Adventure Warrior: Global Edition" (international adventure quests)
- "Te Ara Ahi - The Fire Path" (advanced adventure quest)

**Part of Chain**: 
- New Zealand Cultural & Adventure Series
- Four Elements Warrior Training (expand to other regions)
- Indigenous Culture & Nature series (respectful cultural learning globally)

## Safety & Wellbeing

**Physical Safety**:
- All adventure activities use licensed, safety-certified providers
- Participants must meet provider's health/safety requirements
- Insurance verification required
- Emergency contact information collected

**Emotional Safety**:
- Cultural preparation reduces anxiety of unfamiliar situations
- Dragon challenge is chosen by participant (agency)
- Kahu provides support without pressure
- Option to pause or modify quest if needed
- Debriefing support after intense experiences

**Cultural Safety**:
- Clear protocols for respectful behavior
- Consequences for disrespectful actions
- Support for learning and asking questions appropriately
- Recognition that cultural learning is a journey

---

This quest creates a genuine warrior's journey that respects Māori culture, challenges participants appropriately, and creates authentic transformation through the combination of physical adventure, cultural learning, and personal growth.
