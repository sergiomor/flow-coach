# Example Quest: Micro-Credential Stacker - Digital Marketing

## Quest Overview

**Type**: Career/Certification (Micro-credentials)  
**Duration**: 3-6 months  
**Difficulty**: Beginner-Intermediate  
**Location**: Virtual (online learning)  

## Narrative

The days of needing a full degree to prove your skills are over. Micro-credentials let you stack specific, verifiable competencies that employers actually care about. You're not spending 4 years in a classroom - you're building a targeted skill portfolio that opens doors.

Your guide is Stacker, a career coach who helps people build strategic credential collections that lead to real opportunities. They'll help you design a micro-credential pathway that fits your goals and gets you results.

This quest: Earn 5 stackable digital marketing micro-credentials that qualify you for marketing coordinator roles.

## The Dragon

**Obstacle**: Doubt that micro-credentials are "real" enough  
**Dragon Moment**: Applying for jobs with micro-credentials instead of traditional degree  
**Support**: Stacker provides employer perspective, success stories, application coaching  

## Quest Structure (Abbreviated)

### Task 1: Credential Pathway Design
Design strategic stack of 5 micro-credentials aligned with target roles  

### Task 2: Foundation Credentials (Month 1-2)
Complete 2 foundational credentials: Google Analytics & Social Media Marketing  

### Task 3: Specialization Credentials (Month 3-4)
Complete 2 specialized credentials: SEO & Email Marketing  

### Task 4: Capstone Project Credential (Month 5-6)
Complete portfolio project that demonstrates integrated skills  

### Task 5: The Dragon - Job Applications
Apply for 10 marketing roles using micro-credential portfolio  
**Dragon**: "Will employers take this seriously?"  

### Task 6: Portfolio Presentation
Create professional portfolio showcasing all credentials + project work  

## Rewards

- **5 Industry Micro-Credentials** (Google, HubSpot, Facebook, etc.)
- **Digital Marketing Stacker Badge**
- **Professional Portfolio**
- **Job interviews and offers** (real employment outcomes)
- **Unlocks**: Advanced marketing credentials, specialization tracks

## Why This Quest Works

1. Modern, flexible career development
2. Cost-effective compared to traditional education
3. Stackable = build toward larger qualifications
4. Employer-recognized credentials
5. Practical, applied learning
6. Addresses "legitimacy dragon" directly
7. Clear employment outcomes

---

**Note**: Template adapts for any skill area: data analytics, UX design, project management, cybersecurity, etc.
