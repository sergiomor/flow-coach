# Quest Examples Index

This directory contains comprehensive example quests covering all major categories from the "What do people want to do?" framework.

## Complete Quest Examples (Full Detail)

### 1. **Wellington Food Explorer** (wellington-food-explorer.md)
- **Category**: Experience - Exploration (Culinary)
- **Duration**: 2-4 hours
- **Difficulty**: Beginner
- **Dragon**: Trying new foods outside comfort zone
- **Highlights**: Local Wellington food culture, hidden gems, flavor challenges

### 2. **AI Hacket Champion** (ai-hacket-champion.md)
- **Category**: Experience - Competition (Tech)
- **Duration**: 48 hours (hackathon)
- **Difficulty**: Intermediate
- **Dragon**: Exhaustion and doubt at Hour 24-30
- **Highlights**: Team building, rapid prototyping, persisting through "the grind"

### 3. **Wellington on a Plate Gastronaut** (wellington-on-a-plate-gastronaut.md)
- **Category**: Experience - Exploration (Food Festival)
- **Duration**: 2-4 weeks (during festival)
- **Difficulty**: Beginner
- **Dragon**: Flavor dragon - trying completely unfamiliar ingredients
- **Highlights**: Festival experience, culinary adventure, social dining

### 4. **Rotorua Warrior's Journey** (rotorua-warriors-journey.md)
- **Category**: Experience - Adventure (Cultural & Natural)
- **Duration**: 2-3 days
- **Difficulty**: Intermediate
- **Dragon**: Physical adventure challenge (zipline/rafting/luge)
- **Highlights**: Māori cultural immersion, four elements journey, sacred sites

### 5. **Great Walks: Tongariro Alpine Crossing** (great-walks-tongariro-crossing.md)
- **Category**: Experience - Exploration (Outdoor)
- **Duration**: 6-8 hours hike + prep
- **Difficulty**: Intermediate-Advanced
- **Dragon**: Red Crater ascent - the brutal climb
- **Highlights**: World-class hike, volcanic landscape, epic physical challenge

### 6. **Sales Warrior's Path** (sales-warrior-path.md)
- **Category**: Work - Performance Gamification
- **Duration**: 1 month (recurring)
- **Difficulty**: Intermediate
- **Dragon**: Uncomfortable conversations with cold/stalled leads
- **Highlights**: CRM integration, skill building, call reluctance overcome

### 7. **Quest Maker: Transform Goals Into Quests** (quest-maker-transform-goals.md)
- **Category**: Personal Development - Goal Setting
- **Duration**: 4-6 weeks
- **Difficulty**: Beginner-Intermediate
- **Dragon**: Block Day - 4-6 hours of focused work despite resistance
- **Highlights**: Meta-quest teaching the methodology, completing actual personal quest

### 8. **William Pike Award Journey** (william-pike-award-journey.md)
- **Category**: Personal Development - Youth Award
- **Duration**: 6-12 months
- **Difficulty**: Intermediate
- **Dragon**: Major Project sustained over 3+ months
- **Highlights**: Four-domain development, nationally recognized award, youth transformation

## Abbreviated Quest Examples (Core Structure)

### 9. **SFIA Tech Skills Pathway** (sfia-skills-pathway.md)
- **Category**: Career Progression - Skills Framework
- **Duration**: 6-12 months
- **Dragon**: Imposter syndrome when leading/mentoring
- **Highlights**: Career leveling, salary increase, industry recognition

### 10. **Micro-Credential Stacker** (micro-credentials-pathway.md)
- **Category**: Career/Certification - Credentials
- **Duration**: 3-6 months
- **Dragon**: Doubt that micro-credentials are "real enough"
- **Highlights**: Stackable credentials, employment outcomes, modern career building

### 11. **The Kaitiaki - Environmental Guardian** (environment-conservation-quest.md)
- **Category**: Charitable Service - Environment
- **Duration**: 3 months
- **Dragon**: Feeling individual actions don't matter
- **Highlights**: Hands-on conservation, Māori guardianship concept, visible impact

### 12. **The Competitor** (competition-challenge.md)
- **Category**: Experience - Competition (General)
- **Duration**: 8-12 weeks
- **Dragon**: Fear of losing/performance anxiety on competition day
- **Highlights**: Mental preparation, competing with honor, resilience building

## Coverage of "What Do People Want to Do?" Categories

✅ **Experiences - Fun**
- Competition: AI Hacket, The Competitor
- Adventures: Rotorua Warriors, Great Walks
- Exploration: Wellington Food Explorer, WoaP Gastronaut

✅ **Work**
- Sales Gamification: Sales Warrior's Path

✅ **Personal Development**
- Goal Setting: Quest Maker
- Youth Development: William Pike Award

✅ **Career Progression**
- Skills Framework: SFIA Skills Pathway
- Certifications: Micro-Credential Stacker

✅ **Charitable Service**
- Environment: The Kaitiaki

## Quest Design Patterns Demonstrated

### Narrative Structures
- Hero's journey (William Pike, Great Walks)
- Cultural integration (Rotorua, Kaitiaki)
- Transformation arc (Quest Maker, SFIA)
- Festival/event-based (WoaP, AI Hacket)
- Professional development (Sales Warrior, SFIA)

### Dragon Moments
- Physical endurance (Tongariro Red Crater)
- Social fear (trying new foods, public speaking)
- Sustained effort (William Pike Major Project, Block Day)
- Performance anxiety (AI Hacket Hour 24, Competition Day)
- Imposter syndrome (SFIA mentoring, micro-credential job applications)
- Existential doubt (Kaitiaki "does it matter?")

### NPC Personalities
- Cultural guides (Hēmi, Kahu, Tiaki)
- Professional mentors (Maven, Pathfinder, Stacker)
- Wisdom keepers (Sage, Rangi)
- Challengers (Kōtuku, Challenger, Piki)

### Verification Methods
- Photo + GPS verification (outdoor quests)
- CRM integration (sales quests)
- Official program sync (William Pike, SFIA)
- Self-reporting + NPC review (personal development)
- Booking confirmations (experiences)
- Portfolio evidence (career quests)

### Partnership Models
- Event organizers (WoaP, AI Hacket)
- Conservation groups (Kaitiaki)
- Corporate programs (Sales Warrior, SFIA)
- Youth organizations (William Pike)
- Tourism boards (Rotorua, Great Walks)
- Education providers (Micro-credentials)

## Using These Examples

**For Quest Designers**: Study the full examples to understand complete quest structure, then use abbreviated examples as templates for rapid design.

**For Developers**: Technical verification methods and NPC dialogue patterns are documented in full examples.

**For Partners**: Partnership opportunity sections show how to integrate existing programs with quest platform.

**For Learners**: Use the Quest Design Template in `/templates/` to create your own quests based on these patterns.

## Quest Difficulty Calibration

- **Beginner**: Wellington Food Explorer, Quest Maker, Kaitiaki
- **Intermediate**: AI Hacket, WoaP Gastronaut, Rotorua Warriors, Sales Warrior, William Pike
- **Intermediate-Advanced**: Tongariro Crossing, SFIA progression
- **Advanced**: Multi-day Great Walks, SFIA senior levels

## Next Steps

1. Read full examples to understand quest design depth
2. Review Quest Design Template (`/templates/quest-design-template.md`)
3. Choose activity from your "What do people want to do?" framework
4. Use appropriate example as inspiration
5. Design your quest using the template
6. Test with small user group
7. Iterate based on feedback

---

**Note**: All examples use the core quest framework: Narrative > Dragon Identification > Structured Tasks > NPC Support > Meaningful Rewards > Transformation Focus
