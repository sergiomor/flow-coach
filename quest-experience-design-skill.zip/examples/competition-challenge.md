# Example Quest: The Competitor - Sports Tournament Champion

## Quest Overview

**Type**: Experience (Competition)  
**Duration**: 8-12 weeks (training + event)  
**Difficulty**: Intermediate-Advanced  
**Location**: Various (sport-specific)  

## Narrative

Competition isn't about beating others - it's about discovering what you're capable of when you push yourself against the best. Whether it's a local 5K, a CrossFit competition, a chess tournament, an e-sports event, or a business pitch competition, the quest is the same: Prepare properly, compete with honor, and prove to yourself that you can rise to the challenge.

Your coach is Challenger, a competitive athlete who knows the mental game is as important as physical preparation.

This quest: Train for and compete in your chosen competition, embracing both victory and defeat with grace.

## The Dragon

**Obstacle**: Fear of losing / fear of looking foolish / performance anxiety  
**Dragon Moment**: Competition day when doubt floods in  
**Support**: Challenger provides mental preparation, reframes "losing" as learning, focuses on personal best not placement  

## Quest Structure (Abbreviated)

### Task 1: Competition Selection & Registration
Choose and register for competition 8-12 weeks out  

### Task 2: Training Plan (6-8 weeks)
Follow structured training plan, track progress, build towards peak performance  

### Task 3: Mental Preparation (Weeks 6-8)
Visualization, anxiety management, competition simulation  

### Task 4: The Dragon - Competition Day
Compete despite fear, give full effort regardless of outcome  
**Dragon**: "What if I fail? What if I'm not good enough?"  

### Task 5: Integration & Next Challenge
Reflect on experience, identify growth areas, commit to next competition  

## Rewards

- **Competition Finisher Badge** (specific to event type)
- **Placement/Time** (recorded achievement)
- **Personal Best** (documented improvement)
- **Lessons Learned** (growth through competition)
- **Unlocks**: Advanced competitions, coaching pathways

## Why This Quest Works

1. Real competitive experience
2. Structured preparation reduces anxiety
3. Addresses fear of failure directly
4. Focuses on process and growth over winning
5. Builds resilience and mental toughness
6. Creates community through shared competition
7. Stackable (compete again at higher levels)

---

**Variants**: Any competitive domain - sports, games, business, creative competitions, etc.
