# Example Quest: SFIA Tech Skills Pathways - Level 3 to 4

## Quest Overview

**Type**: Career Progression (Skills Framework)  
**Duration**: 6-12 months  
**Difficulty**: Intermediate  
**Location**: Virtual/Workplace  

## Narrative

The Skills Framework for the Information Age (SFIA) isn't just another corporate framework - it's the global standard for tech professional development. Moving from Level 3 (Apply) to Level 4 (Enable) isn't just a promotion - it's a transformation from someone who does the work to someone who enables others and influences how work gets done.

Your mentor is Pathfinder, a senior tech professional who has navigated SFIA progressions successfully. They know exactly what Level 4 looks like in practice and how to help you build the evidence portfolio that proves you're ready.

This quest: Level up your tech career from practitioner to enabler.

## The Dragon

**Obstacle**: Imposter syndrome / fear you're not "senior enough"  
**Dragon Moment**: First time leading technical decision-making or mentoring others officially  
**Support**: Pathfinder provides frameworks, celebrates early wins, reframes growing pains as growth  

## Quest Structure (Abbreviated)

### Task 1: Skills Gap Analysis
Identify exactly which SFIA skills need development for Level 4  

### Task 2: Technical Depth Projects (3 months)
Complete 2-3 complex technical projects demonstrating Level 4 autonomy  

### Task 3: The Dragon - Enable Others
Lead knowledge sharing, mentor junior staff, influence technical standards  
**Dragon**: "Who am I to teach others? I'm still learning myself."  

### Task 4: Portfolio Building
Document evidence of Level 4 competencies with concrete examples  

### Task 5: Assessment & Progression
Present portfolio, complete SFIA assessment, achieve Level 4 recognition  

## Rewards

- **SFIA Level 4 Certification**
- **Salary increase** (typically 15-25%)
- **Career advancement** opportunities
- **Tech Skills Master Badge**
- **Unlocks**: Senior technical tracks, leadership pathways

## Why This Quest Works

1. Structured career progression in tech
2. Concrete skill development targets
3. Portfolio-based evidence system
4. Addresses imposter syndrome directly
5. Industry-recognized outcome
6. Clear financial and career benefits
7. Builds mentorship and leadership capabilities

---

**Note**: This template adapts for all SFIA levels (1-7) and all 104 SFIA skills across Strategy, Change, Development, Delivery, Skills/Quality, and Relationships.
